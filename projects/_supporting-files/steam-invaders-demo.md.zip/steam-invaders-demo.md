# Steam Invaders

## High Concept
Space Invaders in the age of steam!

## Genre
Classic top/down shooter.

## Platform
Web for desktop.

## Story
Rough draft goes here (yours will be more complete):
- spaceships will attack various steam-centric locales: London factories, English steamships, railoads on the American frontier, ...
- are the invader spaceships also steam powered?
- what is the invader motivation (acquire coal, anthracite, steam technology, ...)?
- ...

## Esthetics
8-bit

## Gameplay
### Mechanics
TBD

### Controls
- keyboard:
  - WASD
  - arrows
  - spacebar
  - "p/P" for pause
  - hold down "s/S" for "steam charge"
  - tap "v/V" for "steam vent"
 - mouse:
   - single click to fire steam bullet
   - double click to fire explosive steam barrel
  
### Teaching the game/New user experience aka "Onboarding"
TBD
 
### Player Learning
TBD

## Screenshots
![Space Steamship](https://i.scdn.co/image/0d367f0b872c1a20c92a25d4c511de7c262bbafa)

## Other
TBD

## About the developer
TBD

## References
- https://en.wikipedia.org/wiki/Naval_tactics_in_the_Age_of_Steam
- [Space Invaders Project](http://www.space-invaders.com/home/)
- ...